/*
*       20103318 김정출
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <errno.h>
#include <netdb.h>

#define IP "127.0.0.1"
#define PORT 9000
#define MAX_CLIENT 1024
#define MAX_DATA 1024
#define MAX_EVENTS 20
#define MAX_CLIENT 20

int num_client = 0;
int client_socket[20];

int setnonblocking(int socket)
{       
        int flag;
        if((flag = fcntl(socket, F_GETFL, 0)) < 0 ) {
                perror("fcntl");
                return -1;
        }
        
        if((fcntl(socket, F_SETFL, flag | O_NONBLOCK)) < 0) { // NON-BLOCK mode add;
                perror("fcntl");
                return -1;
        }
        
        return 0;
}

int main(int argc, char *argv[])
{
        int acceptedSock;
        struct sockaddr_in Addr;
        socklen_t AddrSize = sizeof(Addr);
        char data[MAX_DATA], *p;
        int listenSock, count, i = 1;

        int flag;
        struct epoll_event ev, events[MAX_EVENTS];
        int nfds, epollfd;

        struct addrinfo hints;
        struct addrinfo *result, *rp;
        int s;

        if(argc != 2)
        {       
                fprintf(stderr, "Usage : %s [port]\n", argv[0]);
                exit(0);
        }

        memset(&hints, 0, sizeof(struct addrinfo));

        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags = AI_PASSIVE;

        s = getaddrinfo(NULL, argv[1], &hints, &result);

        if(s != 0) {
                perror("getaddrinfo");
                goto leave;
        }

        for(rp = result; rp != NULL; rp = rp->ai_next) {
                listenSock = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
                if(listenSock == -1)
                        continue;
                if((bind(listenSock, rp->ai_addr, rp->ai_addrlen)) == 0)
                        break;
        }

        if(rp == NULL) {
                perror("Not Bind");
                goto leave;
        }

        freeaddrinfo(result);

                setnonblocking(listenSock);

        if ((listen(listenSock, 1)) < 0 ) {
                perror("listen");
                goto error;
        }

        epollfd = epoll_create(MAX_EVENTS);
        if(epollfd == -1) {
                perror("epoll_create");
                goto error;
        }

        ev.events = EPOLLIN | EPOLLET;
        ev.data.fd = listenSock;

        if(epoll_ctl(epollfd, EPOLL_CTL_ADD, listenSock, &ev) == -1) {
                perror("epoll_ctl :: listen socket");
                goto error;
        }

        for(;;) {
                int n, i;
                if((nfds = epoll_wait(epollfd, events, MAX_EVENTS, 1000)) == -1) {
                        perror("epoll_wait");
                        goto error;
                }

                //printf("number of num_client : %d\n",num_client);

                for(n = 0; n < nfds; n++) {
                        if((events[n].events & EPOLLERR) || (events[n].events & EPOLLHUP) || (!(events[i].events & EPOLLIN))) {
                                perror("epoll error");
                                close(events[n].data.fd);
                                continue;
                        }
                        else if(events[n].data.fd == listenSock) {
                                // accept
                                while(1) {
                                        char hbuf[NI_MAXHOST], sbuf[NI_MAXSERV];
                                        struct sockaddr in_addr;
                                        socklen_t in_len;
                                        in_len = sizeof in_addr;

                                        if((acceptedSock = accept(listenSock, &in_addr, &in_len)) < 0) {
                                                                                        if((errno == EAGAIN) || (errno == EWOULDBLOCK))
                                                        break;
                                                else{
                                                        perror("accept");
                                                        break;
                                                }
                                        }
                                        int s;

                                        s = getnameinfo (&in_addr, in_len,
                                                        hbuf, sizeof hbuf ,
                                                        sbuf, sizeof sbuf ,
                                                        NI_NUMERICHOST | NI_NUMERICSERV);

                                        if(s == 0)
                                                printf("Accepted connection on desriptor %d host=%s, port=%s\n",acceptedSock,hbuf,sbuf);

                                        client_socket[num_client++] = acceptedSock;

                                        setnonblocking(acceptedSock); // set non-block mode
                                        ev.events = EPOLLIN | EPOLLET;
                                        ev.data.fd = acceptedSock;

                                        if(epoll_ctl(epollfd, EPOLL_CTL_ADD, acceptedSock, &ev) == -1) {
                                                perror("epoll_ctl :: accpted socket");
                                                goto error;
                                        }

                                        if(num_client == MAX_CLIENT) {
                                                for(s = 0; s < num_client ; s++)
                                                        send(client_socket[s],"$",2,0);
                                        }
                                }
                                continue;
                        }
                        else {
                                if(num_client == MAX_CLIENT) {
                                        ;
                                }
                        }
                }
        }
error:
        ;
leave:
        ;
}
